<?php

namespace App\Services;

use MercadoPago\Client\Common\RequestOptions;
use MercadoPago\Client\Payment\PaymentClient;
use MercadoPago\Client\Preference\PreferenceClient;
use MercadoPago\Exceptions\MPApiException;
use MercadoPago\MercadoPagoConfig;

class MercadoPagoService
{
    private $paymentClient;
    private $preferenceClient;

    public function __construct()
    {
        MercadoPagoConfig::setAccessToken(config('services.mercadopago.access_token'));
        MercadoPagoConfig::setRuntimeEnviroment(MercadoPagoConfig::PRODUCTION);
        
        $this->paymentClient = new PaymentClient();
        $this->preferenceClient = new PreferenceClient();
    }

    /**
     * Criar uma preferência de pagamento com PIX
     */
    public function createPixPreference($order, $affiliate)
    {
        try {
            $preference = $this->preferenceClient->create([
                "items" => [
                    [
                        "title" => "Pedido #{$order->order_number}",
                        "description" => $order->product_description,
                        "quantity" => $order->quantity,
                        "unit_price" => (float)$order->total_amount,
                    ]
                ],
                "payer" => [
                    "name" => $order->customer_name,
                    "email" => $order->customer_email,
                    "phone" => [
                        "area_code" => "55",
                        "number" => preg_replace('/\D/', '', $order->customer_phone)
                    ],
                    "address" => [
                        "street_name" => $order->shipping_address,
                    ]
                ],
                "payment_methods" => [
                    "excluded_payment_methods" => [
                        [
                            "id" => "amex"
                        ]
                    ],
                    "excluded_payment_types" => [
                        [
                            "id" => "ticket"
                        ]
                    ],
                    "installments" => 1,
                    "default_payment_method_id" => null,
                    "default_installments" => 1
                ],
                "back_urls" => [
                    "success" => route('payment.success'),
                    "failure" => route('payment.failure'),
                    "pending" => route('payment.pending')
                ],
                "auto_return" => "approved",
                "external_reference" => $order->id,
                "expires" => true,
                "expiration_date_from" => now()->toIso8601String(),
                "expiration_date_to" => now()->addHours(24)->toIso8601String(),
            ]);

            return $preference;
        } catch (MPApiException $e) {
            \Log::error('Erro ao criar preferência Mercado Pago: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Obter informações do pagamento
     */
    public function getPaymentInfo($paymentId)
    {
        try {
            $payment = $this->paymentClient->get($paymentId);
            return $payment;
        } catch (MPApiException $e) {
            \Log::error('Erro ao obter informações do pagamento: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Processar webhook de pagamento
     */
    public function processWebhook($data)
    {
        try {
            if ($data['type'] === 'payment') {
                $payment = $this->getPaymentInfo($data['data']['id']);
                return $this->handlePaymentStatus($payment);
            }
        } catch (MPApiException $e) {
            \Log::error('Erro ao processar webhook: ' . $e->getMessage());
            throw $e;
        }
    }

    /**
     * Processar status do pagamento
     */
    private function handlePaymentStatus($payment)
    {
        $externalReference = $payment->external_reference;
        
        $status = match($payment->status) {
            'approved' => 'completed',
            'pending' => 'pending',
            'rejected' => 'failed',
            'cancelled' => 'failed',
            default => 'pending'
        };

        return [
            'external_reference' => $externalReference,
            'payment_id' => $payment->id,
            'status' => $status,
            'payment_method' => $payment->payment_method_id,
            'amount' => $payment->transaction_amount,
        ];
    }

    /**
     * Extrair dados do PIX da resposta
     */
    public function extractPixData($preference)
    {
        $pixData = null;
        
        if (isset($preference->point_of_interaction)) {
            $pointOfInteraction = $preference->point_of_interaction;
            
            if (isset($pointOfInteraction->transaction_data)) {
                $pixData = [
                    'qr_code' => $pointOfInteraction->transaction_data->qr_code ?? null,
                    'copy_paste' => $pointOfInteraction->transaction_data->copy_paste ?? null,
                ];
            }
        }
        
        return $pixData;
    }
}
