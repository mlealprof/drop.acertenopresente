<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AffiliateProduct extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'product_id',
        'custom_price',
        'commission_override',
    ];

    protected $casts = [
        'custom_price' => 'decimal:2',
        'commission_override' => 'decimal:2',
    ];

    /**
     * Relacionamentos
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    /**
     * Métodos
     */
    public function getPrice()
    {
        return $this->custom_price ?? $this->product->price;
    }

    public function getCommission()
    {
        return $this->commission_override ?? $this->user->commission_rate;
    }
}
