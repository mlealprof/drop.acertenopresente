<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Sanctum\HasApiTokens;

class User extends Authenticatable
{
    use HasApiTokens, HasFactory, Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'user_type',
        'cpf',
        'phone',
        'status',
        'balance',
        'commission_rate',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var array<int, string>
     */
    protected $hidden = [
        'password',
        'remember_token',
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'password' => 'hashed',
        'balance' => 'decimal:2',
        'commission_rate' => 'decimal:2',
    ];

    /**
     * Relacionamentos
     */
    public function orders()
    {
        return $this->hasMany(Order::class);
    }

    public function commissions()
    {
        return $this->hasMany(CommissionHistory::class);
    }

    public function affiliateProducts()
    {
        return $this->hasMany(AffiliateProduct::class);
    }

    public function payments()
    {
        return $this->hasMany(Payment::class);
    }

    /**
     * Scopes
     */
    public function scopeAffiliates($query)
    {
        return $query->where('user_type', 'affiliate');
    }

    public function scopeAdmins($query)
    {
        return $query->where('user_type', 'admin');
    }

    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    /**
     * Métodos
     */
    public function isAffiliate()
    {
        return $this->user_type === 'affiliate';
    }

    public function isAdmin()
    {
        return $this->user_type === 'admin';
    }

    public function isActive()
    {
        return $this->status === 'active';
    }

    public function getBalance()
    {
        return $this->balance;
    }

    public function updateBalance($amount)
    {
        $this->balance += $amount;
        $this->save();
    }

    public function deductBalance($amount)
    {
        $this->balance -= $amount;
        $this->save();
    }
}
