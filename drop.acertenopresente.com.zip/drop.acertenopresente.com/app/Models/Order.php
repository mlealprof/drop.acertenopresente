<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    use HasFactory;

    protected $fillable = [
        'user_id',
        'order_number',
        'status',
        'total_amount',
        'commission_amount',
        'shipping_label_url',
        'product_description',
        'quantity',
        'sku',
        'customer_name',
        'customer_email',
        'customer_phone',
        'shipping_address',
    ];

    protected $casts = [
        'total_amount' => 'decimal:2',
        'commission_amount' => 'decimal:2',
    ];

    /**
     * Relacionamentos
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    public function payments()
    {
        return $this->hasMany(Payment::class);
    }

    public function commission()
    {
        return $this->hasOne(CommissionHistory::class);
    }

    /**
     * Scopes
     */
    public function scopeByAffiliate($query, $affiliateId)
    {
        return $query->where('user_id', $affiliateId);
    }

    public function scopeByStatus($query, $status)
    {
        return $query->where('status', $status);
    }

    public function scopePaid($query)
    {
        return $query->where('status', '!=', 'pending');
    }

    public function scopePending($query)
    {
        return $query->where('status', 'pending');
    }

    /**
     * Métodos
     */
    public function markAsPaid()
    {
        $this->status = 'paid';
        $this->save();
    }

    public function markAsInProduction()
    {
        $this->status = 'in_production';
        $this->save();
    }

    public function markAsShipped()
    {
        $this->status = 'shipped';
        $this->save();
    }

    public function markAsDelivered()
    {
        $this->status = 'delivered';
        $this->save();
    }

    public function markAsCancelled()
    {
        $this->status = 'cancelled';
        $this->save();
    }

    public function calculateCommission()
    {
        $commissionRate = $this->user->commission_rate;
        $this->commission_amount = ($this->total_amount * $commissionRate) / 100;
        $this->save();
        return $this->commission_amount;
    }

    public function generateOrderNumber()
    {
        return 'ORD-' . date('YmdHis') . '-' . rand(1000, 9999);
    }
}
