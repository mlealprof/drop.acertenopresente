<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    protected $fillable = [
        'sku',
        'name',
        'description',
        'price',
        'cost',
        'image_url',
        'category',
        'stock_quantity',
        'status',
    ];

    protected $casts = [
        'price' => 'decimal:2',
        'cost' => 'decimal:2',
    ];

    /**
     * Relacionamentos
     */
    public function affiliateProducts()
    {
        return $this->hasMany(AffiliateProduct::class);
    }

    public function orders()
    {
        return $this->hasMany(Order::class, 'sku', 'sku');
    }

    /**
     * Scopes
     */
    public function scopeActive($query)
    {
        return $query->where('status', 'active');
    }

    public function scopeByCategory($query, $category)
    {
        return $query->where('category', $category);
    }

    public function scopeAvailable($query)
    {
        return $query->where('status', 'active')->where('stock_quantity', '>', 0);
    }

    /**
     * Métodos
     */
    public function isAvailable()
    {
        return $this->status === 'active' && $this->stock_quantity > 0;
    }

    public function getCommission($affiliateId = null)
    {
        if ($affiliateId) {
            $affiliateProduct = $this->affiliateProducts()
                ->where('user_id', $affiliateId)
                ->first();

            if ($affiliateProduct && $affiliateProduct->commission_override) {
                return $affiliateProduct->commission_override;
            }
        }

        return 10; // Comissão padrão de 10%
    }

    public function decreaseStock($quantity)
    {
        $this->stock_quantity -= $quantity;
        $this->save();
    }

    public function increaseStock($quantity)
    {
        $this->stock_quantity += $quantity;
        $this->save();
    }
}
