<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\CommissionHistory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class DashboardController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Exibe o dashboard do afiliado
     */
    public function index()
    {
        $user = Auth::user();
        
        $balance = $user->balance;
        $totalOrders = $user->orders()->count();
        $paidOrders = $user->orders()->where('status', '!=', 'pending')->count();
        $pendingOrders = $user->orders()->where('status', 'pending')->count();
        
        $totalCommissions = CommissionHistory::where('user_id', $user->id)->sum('commission_amount');
        $paidCommissions = CommissionHistory::where('user_id', $user->id)->where('status', 'paid')->sum('commission_amount');
        $pendingCommissions = CommissionHistory::where('user_id', $user->id)->where('status', 'pending')->sum('commission_amount');
        
        $recentOrders = $user->orders()->latest()->take(5)->get();
        
        return view('dashboard.index', compact(
            'balance',
            'totalOrders',
            'paidOrders',
            'pendingOrders',
            'totalCommissions',
            'paidCommissions',
            'pendingCommissions',
            'recentOrders'
        ));
    }

    /**
     * Retorna o saldo do afiliado
     */
    public function getBalance()
    {
        $user = Auth::user();
        return response()->json([
            'balance' => $user->balance,
            'formatted' => 'R$ ' . number_format($user->balance, 2, ',', '.')
        ]);
    }

    /**
     * Retorna pedidos pendentes
     */
    public function getPendingOrders()
    {
        $user = Auth::user();
        $orders = $user->orders()->where('status', 'pending')->paginate(10);
        return view('dashboard.pending-orders', compact('orders'));
    }

    /**
     * Retorna pedidos pagos
     */
    public function getPaidOrders()
    {
        $user = Auth::user();
        $orders = $user->orders()->where('status', '!=', 'pending')->paginate(10);
        return view('dashboard.paid-orders', compact('orders'));
    }
}
