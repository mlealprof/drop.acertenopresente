<?php

namespace App\Http\Controllers;

use App\Models\AffiliateProduct;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AffiliateProductController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Lista produtos escolhidos pelo afiliado
     */
    public function index()
    {
        $user = Auth::user();
        $affiliateProducts = $user->affiliateProducts()->with('product')->paginate(12);
        return view('affiliate-products.index', compact('affiliateProducts'));
    }

    /**
     * Adiciona produto ao catálogo do afiliado
     */
    public function add(Request $request)
    {
        $user = Auth::user();
        $product = Product::findOrFail($request->product_id);

        $exists = AffiliateProduct::where('user_id', $user->id)
            ->where('product_id', $product->id)
            ->exists();

        if ($exists) {
            return redirect()->back()->with('error', 'Este produto já está no seu catálogo');
        }

        AffiliateProduct::create([
            'user_id' => $user->id,
            'product_id' => $product->id,
            'custom_price' => null,
            'commission_override' => null,
        ]);

        return redirect()->back()->with('success', 'Produto adicionado com sucesso!');
    }

    /**
     * Remove produto do catálogo do afiliado
     */
    public function remove(AffiliateProduct $affiliateProduct)
    {
        $user = Auth::user();

        if ($affiliateProduct->user_id !== $user->id) {
            return redirect()->back()->with('error', 'Acesso negado');
        }

        $affiliateProduct->delete();
        return redirect()->back()->with('success', 'Produto removido com sucesso!');
    }

    /**
     * Atualiza preço customizado do produto
     */
    public function updatePrice(Request $request, AffiliateProduct $affiliateProduct)
    {
        $user = Auth::user();

        if ($affiliateProduct->user_id !== $user->id) {
            return redirect()->back()->with('error', 'Acesso negado');
        }

        $validated = $request->validate([
            'custom_price' => 'nullable|numeric|min:0',
            'commission_override' => 'nullable|numeric|min:0|max:100',
        ]);

        $affiliateProduct->update($validated);
        return redirect()->back()->with('success', 'Preço atualizado com sucesso!');
    }
}
