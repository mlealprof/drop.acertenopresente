<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Payment;
use App\Models\CommissionHistory;
use App\Services\MercadoPagoService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;

class PaymentController extends Controller
{
    private $mercadoPagoService;

    public function __construct(MercadoPagoService $mercadoPagoService)
    {
        $this->mercadoPagoService = $mercadoPagoService;
        $this->middleware('auth');
    }

    /**
     * Exibe página de pagamento com PIX
     */
    public function showPayment(Order $order)
    {
        $user = Auth::user();

        if ($order->user_id !== $user->id) {
            return redirect()->back()->with('error', 'Acesso negado');
        }

        if ($order->status !== 'pending') {
            return redirect()->back()->with('error', 'Este pedido já foi processado');
        }

        return view('payments.show', compact('order'));
    }

    /**
     * Gerar QR Code PIX para o pedido
     */
    public function generatePixQrCode(Order $order)
    {
        $user = Auth::user();

        if ($order->user_id !== $user->id) {
            return response()->json(['error' => 'Acesso negado'], 403);
        }

        try {
            // Criar preferência de pagamento
            $preference = $this->mercadoPagoService->createPixPreference($order, $user);

            // Extrair dados do PIX
            $pixData = $this->mercadoPagoService->extractPixData($preference);

            // Salvar informações de pagamento
            $payment = Payment::updateOrCreate(
                ['order_id' => $order->id],
                [
                    'user_id' => $user->id,
                    'amount' => $order->total_amount,
                    'payment_method' => 'pix',
                    'payment_date' => now(),
                    'status' => 'pending',
                    'mercadopago_preference_id' => $preference->id,
                    'pix_qr_code' => $pixData['qr_code'] ?? null,
                    'pix_copy_paste' => $pixData['copy_paste'] ?? null,
                    'pix_expiration_date' => now()->addHours(24),
                ]
            );

            return response()->json([
                'success' => true,
                'qr_code' => $pixData['qr_code'] ?? null,
                'copy_paste' => $pixData['copy_paste'] ?? null,
                'preference_id' => $preference->id,
            ]);
        } catch (\Exception $e) {
            Log::error('Erro ao gerar QR Code PIX: ' . $e->getMessage());
            return response()->json(['error' => 'Erro ao gerar QR Code'], 500);
        }
    }

    /**
     * Webhook para processar pagamentos do Mercado Pago
     */
    public function webhook(Request $request)
    {
        try {
            $data = $request->all();
            
            Log::info('Webhook Mercado Pago recebido', $data);

            if ($data['type'] === 'payment') {
                $paymentInfo = $this->mercadoPagoService->processWebhook($data);
                $this->updatePaymentStatus($paymentInfo);
            }

            return response()->json(['success' => true]);
        } catch (\Exception $e) {
            Log::error('Erro ao processar webhook: ' . $e->getMessage());
            return response()->json(['error' => 'Erro ao processar webhook'], 500);
        }
    }

    /**
     * Atualizar status do pagamento
     */
    private function updatePaymentStatus($paymentInfo)
    {
        $payment = Payment::where('mercadopago_preference_id', $paymentInfo['external_reference'])
            ->first();

        if (!$payment) {
            return;
        }

        $payment->update([
            'mercadopago_payment_id' => $paymentInfo['payment_id'],
            'status' => $paymentInfo['status'],
        ]);

        // Se pagamento foi aprovado
        if ($paymentInfo['status'] === 'completed') {
            $order = $payment->order;
            $order->markAsPaid();

            // Calcular e registrar comissão
            $commissionAmount = ($order->total_amount * $order->user->commission_rate) / 100;
            
            CommissionHistory::create([
                'user_id' => $order->user_id,
                'order_id' => $order->id,
                'commission_amount' => $commissionAmount,
                'commission_rate' => $order->user->commission_rate,
                'status' => 'pending',
            ]);
        }
    }

    /**
     * Página de sucesso do pagamento
     */
    public function success(Request $request)
    {
        $preferenceId = $request->get('preference_id');
        
        $payment = Payment::where('mercadopago_preference_id', $preferenceId)->first();

        if ($payment) {
            $payment->update(['status' => 'completed']);
            $payment->order->markAsPaid();
        }

        return view('payments.success', compact('payment'));
    }

    /**
     * Página de falha do pagamento
     */
    public function failure(Request $request)
    {
        $preferenceId = $request->get('preference_id');
        
        $payment = Payment::where('mercadopago_preference_id', $preferenceId)->first();

        return view('payments.failure', compact('payment'));
    }

    /**
     * Página de pagamento pendente
     */
    public function pending(Request $request)
    {
        $preferenceId = $request->get('preference_id');
        
        $payment = Payment::where('mercadopago_preference_id', $preferenceId)->first();

        return view('payments.pending', compact('payment'));
    }

    /**
     * Verificar status do pagamento
     */
    public function checkStatus(Order $order)
    {
        $user = Auth::user();

        if ($order->user_id !== $user->id) {
            return response()->json(['error' => 'Acesso negado'], 403);
        }

        $payment = Payment::where('order_id', $order->id)->first();

        if (!$payment) {
            return response()->json(['status' => 'not_found']);
        }

        return response()->json([
            'status' => $payment->status,
            'order_status' => $order->status,
        ]);
    }
}
