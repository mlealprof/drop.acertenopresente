<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class ProductController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Lista todos os produtos disponíveis
     */
    public function index(Request $request)
    {
        $query = Product::active();

        if ($request->has('search')) {
            $search = $request->get('search');
            $query->where('name', 'like', "%{$search}%")
                  ->orWhere('sku', 'like', "%{$search}%");
        }

        if ($request->has('category')) {
            $query->where('category', $request->get('category'));
        }

        $products = $query->paginate(12);
        $categories = Product::distinct()->pluck('category');

        return view('products.index', compact('products', 'categories'));
    }

    /**
     * Exibe detalhes do produto
     */
    public function show(Product $product)
    {
        return view('products.show', compact('product'));
    }

    /**
     * Busca produtos por nome ou SKU (API)
     */
    public function search(Request $request)
    {
        $search = $request->get('q', '');
        
        $products = Product::active()
            ->where(function ($query) use ($search) {
                $query->where('name', 'like', "%{$search}%")
                      ->orWhere('sku', 'like', "%{$search}%");
            })
            ->limit(10)
            ->get(['id', 'sku', 'name', 'price']);

        return response()->json($products);
    }
}
