<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Product;
use App\Models\Order;
use App\Models\Payment;
use App\Models\CommissionHistory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->middleware('admin');
    }

    /**
     * Dashboard administrativo
     */
    public function dashboard()
    {
        $totalAffiliates = User::where('user_type', 'affiliate')->count();
        $totalProducts = Product::count();
        $totalOrders = Order::count();
        $totalRevenue = Order::sum('total_amount');
        $totalCommissions = CommissionHistory::sum('commission_amount');

        $recentOrders = Order::latest()->take(10)->get();
        $topAffiliates = User::where('user_type', 'affiliate')
            ->withCount('orders')
            ->orderBy('orders_count', 'desc')
            ->take(5)
            ->get();

        return view('admin.dashboard', compact(
            'totalAffiliates',
            'totalProducts',
            'totalOrders',
            'totalRevenue',
            'totalCommissions',
            'recentOrders',
            'topAffiliates'
        ));
    }

    /**
     * Gerencia afiliados
     */
    public function manageAffiliates(Request $request)
    {
        $query = User::where('user_type', 'affiliate');

        if ($request->has('search')) {
            $search = $request->get('search');
            $query->where('name', 'like', "%{$search}%")
                  ->orWhere('email', 'like', "%{$search}%");
        }

        $affiliates = $query->paginate(15);
        return view('admin.affiliates.index', compact('affiliates'));
    }

    /**
     * Exibe detalhes do afiliado
     */
    public function showAffiliate(User $user)
    {
        if ($user->user_type !== 'affiliate') {
            return redirect()->back()->with('error', 'Usuário não é um afiliado');
        }

        $totalOrders = $user->orders()->count();
        $totalCommissions = CommissionHistory::where('user_id', $user->id)->sum('commission_amount');
        $paidCommissions = CommissionHistory::where('user_id', $user->id)->where('status', 'paid')->sum('commission_amount');
        $recentOrders = $user->orders()->latest()->take(10)->get();

        return view('admin.affiliates.show', compact(
            'user',
            'totalOrders',
            'totalCommissions',
            'paidCommissions',
            'recentOrders'
        ));
    }

    /**
     * Atualiza status do afiliado
     */
    public function updateAffiliateStatus(Request $request, User $user)
    {
        $validated = $request->validate([
            'status' => 'required|in:active,inactive,suspended',
        ]);

        $user->update($validated);
        return redirect()->back()->with('success', 'Status do afiliado atualizado!');
    }

    /**
     * Gerencia produtos
     */
    public function manageProducts(Request $request)
    {
        $query = Product::query();

        if ($request->has('search')) {
            $search = $request->get('search');
            $query->where('name', 'like', "%{$search}%")
                  ->orWhere('sku', 'like', "%{$search}%");
        }

        $products = $query->paginate(15);
        return view('admin.products.index', compact('products'));
    }

    /**
     * Cria novo produto
     */
    public function createProduct()
    {
        return view('admin.products.create');
    }

    /**
     * Armazena novo produto
     */
    public function storeProduct(Request $request)
    {
        $validated = $request->validate([
            'sku' => 'required|unique:products,sku',
            'name' => 'required|string',
            'description' => 'nullable|string',
            'price' => 'required|numeric|min:0',
            'cost' => 'nullable|numeric|min:0',
            'category' => 'nullable|string',
            'stock_quantity' => 'required|integer|min:0',
        ]);

        Product::create($validated);
        return redirect()->route('admin.products.index')->with('success', 'Produto criado com sucesso!');
    }

    /**
     * Edita produto
     */
    public function editProduct(Product $product)
    {
        return view('admin.products.edit', compact('product'));
    }

    /**
     * Atualiza produto
     */
    public function updateProduct(Request $request, Product $product)
    {
        $validated = $request->validate([
            'sku' => 'required|unique:products,sku,' . $product->id,
            'name' => 'required|string',
            'description' => 'nullable|string',
            'price' => 'required|numeric|min:0',
            'cost' => 'nullable|numeric|min:0',
            'category' => 'nullable|string',
            'stock_quantity' => 'required|integer|min:0',
            'status' => 'required|in:active,inactive',
        ]);

        $product->update($validated);
        return redirect()->route('admin.products.index')->with('success', 'Produto atualizado com sucesso!');
    }

    /**
     * Deleta produto
     */
    public function deleteProduct(Product $product)
    {
        $product->delete();
        return redirect()->route('admin.products.index')->with('success', 'Produto deletado com sucesso!');
    }

    /**
     * Gerencia pedidos
     */
    public function manageOrders(Request $request)
    {
        $query = Order::query();

        if ($request->has('status')) {
            $query->where('status', $request->get('status'));
        }

        $orders = $query->latest()->paginate(15);
        return view('admin.orders.index', compact('orders'));
    }

    /**
     * Atualiza status do pedido
     */
    public function updateOrderStatus(Request $request, Order $order)
    {
        $validated = $request->validate([
            'status' => 'required|in:pending,paid,in_production,shipped,delivered,cancelled',
        ]);

        $order->update($validated);
        return redirect()->back()->with('success', 'Status do pedido atualizado!');
    }

    /**
     * Gerencia pagamentos
     */
    public function managePayments(Request $request)
    {
        $query = CommissionHistory::query();

        if ($request->has('status')) {
            $query->where('status', $request->get('status'));
        }

        $commissions = $query->latest()->paginate(15);
        return view('admin.payments.index', compact('commissions'));
    }

    /**
     * Marca comissão como paga
     */
    public function payCommission(CommissionHistory $commission)
    {
        $commission->markAsPaid();
        $commission->user->updateBalance($commission->commission_amount);

        return redirect()->back()->with('success', 'Comissão marcada como paga!');
    }
}
