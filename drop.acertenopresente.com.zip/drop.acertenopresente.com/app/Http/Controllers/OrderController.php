<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\CommissionHistory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Storage;

class OrderController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Lista pedidos do afiliado
     */
    public function index(Request $request)
    {
        $user = Auth::user();
        $query = $user->orders();

        if ($request->has('status')) {
            $query->where('status', $request->get('status'));
        }

        $orders = $query->latest()->paginate(10);
        return view('orders.index', compact('orders'));
    }

    /**
     * Exibe formulário para criar novo pedido
     */
    public function create()
    {
        $user = Auth::user();
        $affiliateProducts = $user->affiliateProducts()->with('product')->get();
        return view('orders.create', compact('affiliateProducts'));
    }

    /**
     * Armazena novo pedido com upload de etiqueta
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'sku' => 'required|string',
            'product_description' => 'required|string',
            'quantity' => 'required|integer|min:1',
            'total_amount' => 'required|numeric|min:0',
            'customer_name' => 'required|string',
            'customer_email' => 'required|email',
            'customer_phone' => 'required|string',
            'shipping_address' => 'required|string',
            'shipping_label' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
        ]);

        $user = Auth::user();

        $order = new Order();
        $order->user_id = $user->id;
        $order->order_number = $order->generateOrderNumber();
        $order->sku = $validated['sku'];
        $order->product_description = $validated['product_description'];
        $order->quantity = $validated['quantity'];
        $order->total_amount = $validated['total_amount'];
        $order->customer_name = $validated['customer_name'];
        $order->customer_email = $validated['customer_email'];
        $order->customer_phone = $validated['customer_phone'];
        $order->shipping_address = $validated['shipping_address'];
        $order->status = 'pending';

        if ($request->hasFile('shipping_label')) {
            $path = $request->file('shipping_label')->store('shipping-labels', 'public');
            $order->shipping_label_url = $path;
        }

        $order->save();

        return redirect()->route('orders.show', $order)->with('success', 'Pedido criado com sucesso!');
    }

    /**
     * Exibe detalhes do pedido
     */
    public function show(Order $order)
    {
        $user = Auth::user();

        if ($order->user_id !== $user->id) {
            return redirect()->back()->with('error', 'Acesso negado');
        }

        return view('orders.show', compact('order'));
    }

    /**
     * Exibe formulário para editar pedido
     */
    public function edit(Order $order)
    {
        $user = Auth::user();

        if ($order->user_id !== $user->id) {
            return redirect()->back()->with('error', 'Acesso negado');
        }

        return view('orders.edit', compact('order'));
    }

    /**
     * Atualiza pedido
     */
    public function update(Request $request, Order $order)
    {
        $user = Auth::user();

        if ($order->user_id !== $user->id) {
            return redirect()->back()->with('error', 'Acesso negado');
        }

        $validated = $request->validate([
            'product_description' => 'required|string',
            'quantity' => 'required|integer|min:1',
            'total_amount' => 'required|numeric|min:0',
            'customer_name' => 'required|string',
            'customer_email' => 'required|email',
            'customer_phone' => 'required|string',
            'shipping_address' => 'required|string',
            'shipping_label' => 'nullable|file|mimes:pdf,jpg,jpeg,png|max:5120',
        ]);

        $order->product_description = $validated['product_description'];
        $order->quantity = $validated['quantity'];
        $order->total_amount = $validated['total_amount'];
        $order->customer_name = $validated['customer_name'];
        $order->customer_email = $validated['customer_email'];
        $order->customer_phone = $validated['customer_phone'];
        $order->shipping_address = $validated['shipping_address'];

        if ($request->hasFile('shipping_label')) {
            if ($order->shipping_label_url) {
                Storage::disk('public')->delete($order->shipping_label_url);
            }
            $path = $request->file('shipping_label')->store('shipping-labels', 'public');
            $order->shipping_label_url = $path;
        }

        $order->save();

        return redirect()->route('orders.show', $order)->with('success', 'Pedido atualizado com sucesso!');
    }

    /**
     * Deleta pedido
     */
    public function destroy(Order $order)
    {
        $user = Auth::user();

        if ($order->user_id !== $user->id) {
            return redirect()->back()->with('error', 'Acesso negado');
        }

        if ($order->shipping_label_url) {
            Storage::disk('public')->delete($order->shipping_label_url);
        }

        $order->delete();
        return redirect()->route('orders.index')->with('success', 'Pedido deletado com sucesso!');
    }

    /**
     * Lista pedidos pagos
     */
    public function paidOrders()
    {
        $user = Auth::user();
        $orders = $user->orders()->where('status', '!=', 'pending')->latest()->paginate(10);
        return view('orders.paid', compact('orders'));
    }
}
