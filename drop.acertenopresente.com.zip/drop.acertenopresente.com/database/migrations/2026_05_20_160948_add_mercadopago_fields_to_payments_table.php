<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            $table->string('mercadopago_preference_id')->nullable();
            $table->string('mercadopago_payment_id')->nullable();
            $table->string('pix_qr_code')->nullable();
            $table->string('pix_copy_paste')->nullable();
            $table->dateTime('pix_expiration_date')->nullable();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('payments', function (Blueprint $table) {
            $table->dropColumn(['mercadopago_preference_id', 'mercadopago_payment_id', 'pix_qr_code', 'pix_copy_paste', 'pix_expiration_date']);
        });
    }
};
