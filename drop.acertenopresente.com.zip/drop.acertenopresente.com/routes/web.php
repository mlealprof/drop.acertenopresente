<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\AffiliateProductController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\AdminController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

// Página inicial
Route::get('/', function () {
    if (auth()->check()) {
        return redirect()->route('dashboard');
    }
    return redirect()->route('login');
})->name('home');

// Rotas de Autenticação (Públicas)
Route::middleware('guest')->group(function () {
    Route::get('/login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('/login', [AuthController::class, 'login'])->name('login.post');
    Route::get('/register', [AuthController::class, 'showRegister'])->name('register');
    Route::post('/register', [AuthController::class, 'register'])->name('register.post');
});

// Logout
Route::post('/logout', [AuthController::class, 'logout'])->name('logout')->middleware('auth');

// Rotas Protegidas (Afiliados)
Route::middleware('auth')->group(function () {
    // Dashboard
    Route::get('/dashboard', [DashboardController::class, 'index'])->name('dashboard');
    Route::get('/api/balance', [DashboardController::class, 'getBalance'])->name('balance');

    // Catálogo de Produtos
    Route::get('/catalog', [ProductController::class, 'index'])->name('products.index');
    Route::get('/products/{product}', [ProductController::class, 'show'])->name('products.show');
    Route::get('/api/products/search', [ProductController::class, 'search'])->name('products.search');

    // Produtos Escolhidos
    Route::get('/my-products', [AffiliateProductController::class, 'index'])->name('affiliate-products.index');
    Route::post('/my-products/add', [AffiliateProductController::class, 'add'])->name('affiliate-products.add');
    Route::delete('/my-products/{affiliateProduct}', [AffiliateProductController::class, 'remove'])->name('affiliate-products.remove');
    Route::put('/my-products/{affiliateProduct}/price', [AffiliateProductController::class, 'updatePrice'])->name('affiliate-products.update-price');

    // Pedidos
    Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');
    Route::get('/orders/create', [OrderController::class, 'create'])->name('orders.create');
    Route::post('/orders', [OrderController::class, 'store'])->name('orders.store');
    Route::get('/orders/{order}', [OrderController::class, 'show'])->name('orders.show');
    Route::get('/orders/{order}/edit', [OrderController::class, 'edit'])->name('orders.edit');
    Route::put('/orders/{order}', [OrderController::class, 'update'])->name('orders.update');
    Route::delete('/orders/{order}', [OrderController::class, 'destroy'])->name('orders.destroy');

    // Pedidos Pagos
    Route::get('/paid-orders', [OrderController::class, 'paidOrders'])->name('orders.paid');
});

// Rotas Administrativas
Route::middleware(['auth', 'admin'])->prefix('admin')->name('admin.')->group(function () {
    Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');

    // Gerenciamento de Afiliados
    Route::get('/affiliates', [AdminController::class, 'manageAffiliates'])->name('affiliates.index');
    Route::get('/affiliates/{user}', [AdminController::class, 'showAffiliate'])->name('affiliates.show');
    Route::put('/affiliates/{user}/status', [AdminController::class, 'updateAffiliateStatus'])->name('affiliates.update-status');

    // Gerenciamento de Produtos
    Route::get('/products', [AdminController::class, 'manageProducts'])->name('products.index');
    Route::get('/products/create', [AdminController::class, 'createProduct'])->name('products.create');
    Route::post('/products', [AdminController::class, 'storeProduct'])->name('products.store');
    Route::get('/products/{product}/edit', [AdminController::class, 'editProduct'])->name('products.edit');
    Route::put('/products/{product}', [AdminController::class, 'updateProduct'])->name('products.update');
    Route::delete('/products/{product}', [AdminController::class, 'deleteProduct'])->name('products.destroy');

    // Gerenciamento de Pedidos
    Route::get('/orders', [AdminController::class, 'manageOrders'])->name('orders.index');
    Route::put('/orders/{order}/status', [AdminController::class, 'updateOrderStatus'])->name('orders.update-status');

    // Gerenciamento de Pagamentos/Comissões
    Route::get('/payments', [AdminController::class, 'managePayments'])->name('payments.index');
    Route::put('/payments/{commission}/pay', [AdminController::class, 'payCommission'])->name('payments.pay');
});

// Rotas de Pagamento
Route::middleware('auth')->group(function () {
    Route::get('/payment/{order}', [PaymentController::class, 'showPayment'])->name('payment.show');
    Route::post('/payment/{order}/generate-pix', [PaymentController::class, 'generatePixQrCode'])->name('payment.generate-pix');
    Route::get('/payment/{order}/check-status', [PaymentController::class, 'checkStatus'])->name('payment.check-status');
});

// Webhooks (sem autenticação)
Route::post('/webhook/mercadopago', [PaymentController::class, 'webhook'])->name('webhook.mercadopago');

// Callbacks de pagamento
Route::get('/payment/success', [PaymentController::class, 'success'])->name('payment.success');
Route::get('/payment/failure', [PaymentController::class, 'failure'])->name('payment.failure');
Route::get('/payment/pending', [PaymentController::class, 'pending'])->name('payment.pending');
