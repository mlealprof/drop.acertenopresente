# Drop Acerte no Presente - Plataforma de Dropshipping

Uma plataforma moderna e completa de gerenciamento de afiliados para dropshipping, desenvolvida com Laravel 11 e Tailwind CSS.

## Características Principais

### Para Afiliados
- **Dashboard Intuitivo**: Visualize seu saldo, comissões e estatísticas em tempo real
- **Catálogo de Produtos**: Acesso a todos os produtos disponíveis com busca e filtros
- **Produtos Escolhidos**: Selecione produtos para vender e customize preços
- **Gerenciamento de Pedidos**: Crie, edite e acompanhe pedidos com upload de etiquetas
- **Pedidos Pagos**: Visualize pedidos confirmados em produção/postagem
- **Histórico de Comissões**: Acompanhe todas as suas comissões e pagamentos

### Para Administradores
- **Dashboard Administrativo**: Estatísticas gerais e métricas de negócio
- **Gerenciamento de Afiliados**: Controle total sobre afiliados (ativar, desativar, suspender)
- **Gerenciamento de Produtos**: CRUD completo de produtos com SKU e estoque
- **Gerenciamento de Pedidos**: Visualize e atualize status de todos os pedidos
- **Gerenciamento de Pagamentos**: Processe pagamentos de comissões aos afiliados

## Tecnologias Utilizadas

| Tecnologia | Versão | Propósito |
|-----------|--------|----------|
| Laravel | 11.x | Framework PHP |
| PHP | 8.1+ | Linguagem de programação |
| MySQL | 8.0+ | Banco de dados |
| Tailwind CSS | 2.2+ | Estilização |
| Blade | - | Template engine |

## Estrutura do Projeto

```
drop.acertenopresente.com/
├── app/
│   ├── Http/Controllers/
│   │   ├── AuthController.php
│   │   ├── DashboardController.php
│   │   ├── ProductController.php
│   │   ├── AffiliateProductController.php
│   │   ├── OrderController.php
│   │   └── AdminController.php
│   ├── Models/
│   │   ├── User.php
│   │   ├── Product.php
│   │   ├── AffiliateProduct.php
│   │   ├── Order.php
│   │   ├── Payment.php
│   │   └── CommissionHistory.php
│   └── Middleware/
│       └── AdminMiddleware.php
├── database/
│   └── migrations/
├── resources/
│   └── views/
│       ├── auth/
│       ├── dashboard/
│       ├── products/
│       ├── orders/
│       ├── admin/
│       └── layouts/
├── routes/
│   └── web.php
├── ARCHITECTURE.md
└── DEPLOYMENT_GUIDE.md
```

## Instalação Local

### Pré-requisitos
- PHP 8.1 ou superior
- Composer
- MySQL 8.0 ou superior
- Node.js (para assets)

### Passos

1. **Clone o repositório**
```bash
git clone https://seu-repositorio.git
cd drop.acertenopresente.com
```

2. **Instale dependências**
```bash
composer install
npm install
```

3. **Configure o ambiente**
```bash
cp .env.example .env
php artisan key:generate
```

4. **Configure o banco de dados**
Edite o arquivo `.env` com suas credenciais:
```
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=drop_db
DB_USERNAME=root
DB_PASSWORD=
```

5. **Execute as migrations**
```bash
php artisan migrate
```

6. **Inicie o servidor**
```bash
php artisan serve
```

A aplicação estará disponível em `http://localhost:8000`

## Deployment

Para instruções detalhadas de deploy na Hostgator, consulte o arquivo [DEPLOYMENT_GUIDE.md](DEPLOYMENT_GUIDE.md).

## Arquitetura

Para entender a arquitetura completa do projeto, consulte [ARCHITECTURE.md](ARCHITECTURE.md).

## Rotas Principais

### Autenticação
- `GET /login` - Formulário de login
- `POST /login` - Processar login
- `GET /register` - Formulário de registro
- `POST /register` - Processar registro
- `POST /logout` - Logout

### Dashboard do Afiliado
- `GET /dashboard` - Dashboard principal
- `GET /api/balance` - Obter saldo (JSON)

### Catálogo de Produtos
- `GET /catalog` - Listar produtos
- `GET /products/{id}` - Detalhes do produto
- `GET /api/products/search` - Buscar produtos (JSON)

### Produtos Escolhidos
- `GET /my-products` - Listar produtos do afiliado
- `POST /my-products/add` - Adicionar produto
- `DELETE /my-products/{id}` - Remover produto
- `PUT /my-products/{id}/price` - Atualizar preço

### Pedidos
- `GET /orders` - Listar pedidos
- `GET /orders/create` - Formulário de novo pedido
- `POST /orders` - Criar pedido
- `GET /orders/{id}` - Detalhes do pedido
- `GET /orders/{id}/edit` - Editar pedido
- `PUT /orders/{id}` - Atualizar pedido
- `DELETE /orders/{id}` - Deletar pedido
- `GET /paid-orders` - Listar pedidos pagos

### Admin
- `GET /admin/dashboard` - Dashboard administrativo
- `GET /admin/affiliates` - Gerenciar afiliados
- `GET /admin/products` - Gerenciar produtos
- `GET /admin/orders` - Gerenciar pedidos
- `GET /admin/payments` - Gerenciar pagamentos

## Modelos de Dados

### User
- Armazena informações de usuários (afiliados e admins)
- Campos: name, email, password, user_type, cpf, phone, status, balance, commission_rate

### Product
- Catálogo de produtos disponíveis
- Campos: sku, name, description, price, cost, image_url, category, stock_quantity, status

### AffiliateProduct
- Produtos selecionados por afiliados
- Permite customizar preço e comissão por afiliado

### Order
- Pedidos criados pelos afiliados
- Rastreia cliente, valor, status e etiqueta de envio

### Payment
- Registro de pagamentos dos pedidos
- Armazena método, data e status do pagamento

### CommissionHistory
- Histórico de comissões dos afiliados
- Permite rastrear comissões pagas e pendentes

## Segurança

- Autenticação com hash bcrypt
- Proteção CSRF em todos os formulários
- Validação de entrada em todos os endpoints
- Middleware de autorização para admin
- Rate limiting em endpoints críticos
- Sanitização de dados de entrada

## Contribuindo

Para contribuir com o projeto, siga os padrões PSR-12 de codificação PHP.

## Licença

Este projeto é proprietário e confidencial.

## Suporte

Para suporte técnico, entre em contato com o administrador do sistema.

## Changelog

### Versão 1.0.0 (2026-05-20)
- Lançamento inicial
- Autenticação de usuários
- Dashboard de afiliados
- Gerenciamento de produtos
- Sistema de pedidos
- Painel administrativo
- Gerenciamento de comissões

