# Guia de Deploy - Drop Acerte no Presente

## Visão Geral

Este guia fornece instruções passo a passo para fazer o deploy da plataforma de dropshipping na Hostgator.

## Pré-requisitos

- Acesso SSH à Hostgator
- Domínio: `drop.acertenopresente.com`
- Banco de dados: `thequ927_drop`
- Usuário: `thequ927_teste`
- Senha: `thequ927_teste`
- PHP 8.1+ instalado
- Composer instalado
- Git instalado

## Passo 1: Preparar o Servidor

### 1.1 Conectar via SSH

```bash
ssh user@seu-servidor.hostgator.com
```

### 1.2 Navegar até o diretório público

```bash
cd ~/public_html
```

### 1.3 Remover arquivos padrão (se houver)

```bash
rm -rf *
```

## Passo 2: Clonar o Projeto

### 2.1 Clonar do repositório Git

Se você estiver usando Git:

```bash
git clone https://seu-repositorio.git .
```

Ou, se preferir fazer upload manual:

1. Compacte o projeto localmente: `zip -r drop.zip .`
2. Faça upload via FTP/SFTP para `~/public_html/`
3. Descompacte: `unzip drop.zip`

## Passo 3: Instalar Dependências

### 3.1 Instalar Composer

```bash
curl -sS https://getcomposer.org/installer | php
```

### 3.2 Instalar dependências do projeto

```bash
php composer.phar install --no-dev --optimize-autoloader
```

## Passo 4: Configurar o Ambiente

### 4.1 Copiar arquivo .env

```bash
cp .env.example .env
```

### 4.2 Gerar chave da aplicação

```bash
php artisan key:generate
```

### 4.3 Editar o arquivo .env

```bash
nano .env
```

Certifique-se de que as seguintes configurações estão corretas:

```
APP_NAME="Drop Acerte no Presente"
APP_ENV=production
APP_DEBUG=false
APP_URL=https://drop.acertenopresente.com

DB_CONNECTION=mysql
DB_HOST=localhost
DB_PORT=3306
DB_DATABASE=thequ927_drop
DB_USERNAME=thequ927_teste
DB_PASSWORD=thequ927_teste

MAIL_MAILER=smtp
MAIL_HOST=seu-smtp.hostgator.com
MAIL_PORT=587
MAIL_USERNAME=seu-email@drop.acertenopresente.com
MAIL_PASSWORD=sua-senha
MAIL_ENCRYPTION=tls
MAIL_FROM_ADDRESS=seu-email@drop.acertenopresente.com
```

## Passo 5: Configurar Permissões

### 5.1 Definir permissões corretas

```bash
chmod -R 755 storage
chmod -R 755 bootstrap/cache
chmod -R 755 public
```

### 5.2 Definir proprietário

```bash
chown -R nobody:nobody storage bootstrap/cache public
```

## Passo 6: Executar Migrations

### 6.1 Criar tabelas no banco de dados

```bash
php artisan migrate --force
```

### 6.2 (Opcional) Seed de dados iniciais

```bash
php artisan db:seed --class=AdminSeeder
```

## Passo 7: Configurar o Servidor Web

### 7.1 Configurar .htaccess (Apache)

Certifique-se de que o arquivo `public/.htaccess` existe. Se não existir, crie-o:

```bash
cat > public/.htaccess << 'HTACCESS'
<IfModule mod_rewrite.c>
    <IfModule mod_negotiation.c>
        Options -MultiViews
    </IfModule>

    RewriteEngine On

    # Redirect Trailing Slashes If Not A Folder...
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_URI} (.+)/$
    RewriteRule ^ %1 [L,R=301]

    # Handle Front Controller...
    RewriteCond %{REQUEST_FILENAME} !-d
    RewriteCond %{REQUEST_FILENAME} !-f
    RewriteRule ^ index.php [L]
</IfModule>
```

### 7.2 Configurar DocumentRoot (cPanel)

1. Acesse cPanel
2. Vá para "Addon Domains" ou "Domains"
3. Defina o Document Root para: `/home/seu-usuario/public_html/public`

## Passo 8: Otimizar para Produção

### 8.1 Limpar cache

```bash
php artisan cache:clear
php artisan config:clear
php artisan view:clear
php artisan route:clear
```

### 8.2 Gerar cache otimizado

```bash
php artisan config:cache
php artisan route:cache
php artisan view:cache
```

## Passo 9: Configurar SSL/HTTPS

### 9.1 Usar Let's Encrypt (recomendado)

1. Acesse cPanel
2. Vá para "AutoSSL" ou "SSL/TLS"
3. Instale um certificado SSL gratuito

### 9.2 Forçar HTTPS no Laravel

Edite `app/Providers/AppServiceProvider.php`:

```php
public function boot()
{
    if (env('APP_ENV') === 'production') {
        URL::forceScheme('https');
    }
}
```

## Passo 10: Criar Usuário Admin (Primeira Vez)

### 10.1 Criar um usuário administrador

```bash
php artisan tinker
```

Dentro do Tinker:

```php
$user = App\Models\User::create([
    'name' => 'Administrador',
    'email' => 'admin@drop.acertenopresente.com',
    'password' => bcrypt('senha-segura'),
    'user_type' => 'admin',
    'status' => 'active',
    'balance' => 0,
    'commission_rate' => 0,
]);
```

## Passo 11: Configurar Cron Jobs (Opcional)

Para tarefas agendadas, adicione ao crontab:

```bash
crontab -e
```

Adicione:

```
* * * * * cd /home/seu-usuario/public_html && php artisan schedule:run >> /dev/null 2>&1
```

## Passo 12: Monitorar e Manter

### 12.1 Verificar logs

```bash
tail -f storage/logs/laravel.log
```

### 12.2 Fazer backup regular

```bash
php artisan backup:run
```

### 12.3 Atualizar dependências

```bash
composer update --no-dev
```

## Troubleshooting

### Erro: "The storage path does not exist"

```bash
mkdir -p storage/app/public
php artisan storage:link
```

### Erro: "No application encryption key has been specified"

```bash
php artisan key:generate
```

### Erro: "SQLSTATE[HY000]: General error: 1030 Got error"

Verifique o espaço em disco e as permissões do banco de dados.

### Erro: "Class not found"

```bash
composer dump-autoload
```

## Segurança

1. Altere a senha padrão do admin imediatamente
2. Mantenha o Laravel e dependências atualizados
3. Configure firewall adequadamente
4. Faça backups regulares
5. Monitore logs de erro
6. Use HTTPS em produção
7. Defina `APP_DEBUG=false` em produção

## Suporte

Para problemas, consulte:
- [Documentação Laravel](https://laravel.com/docs)
- [Fórum Hostgator](https://www.hostgator.com/support)
- Logs em `storage/logs/laravel.log`


## Passo 13: Configurar Mercado Pago

### 13.1 Obter Credenciais
1. Acesse o painel do Mercado Pago Developers
2. Crie uma aplicação
3. Obtenha o `Access Token` e `Public Key` de produção

### 13.2 Configurar no .env
Adicione as credenciais no arquivo `.env` do servidor:
```
MERCADOPAGO_ACCESS_TOKEN=seu_access_token_aqui
MERCADOPAGO_PUBLIC_KEY=sua_public_key_aqui
```

### 13.3 Configurar Webhooks
1. No painel do Mercado Pago, vá em "Webhooks"
2. Adicione a URL: `https://drop.acertenopresente.com/webhook/mercadopago`
3. Selecione os eventos: `Pagamentos`
