@extends('layouts.app')

@section('title', 'Dashboard - Drop Acerte no Presente')

@section('content')
<div class="max-w-7xl mx-auto">
    <h1 class="text-4xl font-bold text-gray-900 mb-8">Dashboard</h1>

    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-gray-600 text-sm font-medium">Saldo Disponível</h3>
            <p class="text-3xl font-bold text-blue-600 mt-2">R$ {{ number_format($balance, 2, ',', '.') }}</p>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-gray-600 text-sm font-medium">Total de Pedidos</h3>
            <p class="text-3xl font-bold text-green-600 mt-2">{{ $totalOrders }}</p>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-gray-600 text-sm font-medium">Pedidos Pagos</h3>
            <p class="text-3xl font-bold text-purple-600 mt-2">{{ $paidOrders }}</p>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <h3 class="text-gray-600 text-sm font-medium">Comissões Pendentes</h3>
            <p class="text-3xl font-bold text-orange-600 mt-2">R$ {{ number_format($pendingCommissions, 2, ',', '.') }}</p>
        </div>
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div class="bg-white rounded-lg shadow p-6">
            <h2 class="text-2xl font-bold text-gray-900 mb-4">Comissões</h2>
            <div class="space-y-2">
                <p class="text-gray-600">Total de Comissões: <span class="font-bold">R$ {{ number_format($totalCommissions, 2, ',', '.') }}</span></p>
                <p class="text-gray-600">Comissões Pagas: <span class="font-bold text-green-600">R$ {{ number_format($paidCommissions, 2, ',', '.') }}</span></p>
                <p class="text-gray-600">Comissões Pendentes: <span class="font-bold text-orange-600">R$ {{ number_format($pendingCommissions, 2, ',', '.') }}</span></p>
            </div>
        </div>

        <div class="bg-white rounded-lg shadow p-6">
            <h2 class="text-2xl font-bold text-gray-900 mb-4">Ações Rápidas</h2>
            <div class="space-y-2">
                <a href="{{ route('products.index') }}" class="block bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 text-center">
                    Ver Catálogo de Produtos
                </a>
                <a href="{{ route('orders.create') }}" class="block bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700 text-center">
                    Criar Novo Pedido
                </a>
                <a href="{{ route('orders.index') }}" class="block bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700 text-center">
                    Ver Meus Pedidos
                </a>
            </div>
        </div>
    </div>

    <div class="bg-white rounded-lg shadow p-6 mt-8">
        <h2 class="text-2xl font-bold text-gray-900 mb-4">Pedidos Recentes</h2>
        @if($recentOrders->count() > 0)
            <div class="overflow-x-auto">
                <table class="w-full">
                    <thead class="bg-gray-100">
                        <tr>
                            <th class="px-4 py-2 text-left">Número</th>
                            <th class="px-4 py-2 text-left">Cliente</th>
                            <th class="px-4 py-2 text-left">Valor</th>
                            <th class="px-4 py-2 text-left">Status</th>
                            <th class="px-4 py-2 text-left">Data</th>
                        </tr>
                    </thead>
                    <tbody>
                        @foreach($recentOrders as $order)
                            <tr class="border-t">
                                <td class="px-4 py-2">{{ $order->order_number }}</td>
                                <td class="px-4 py-2">{{ $order->customer_name }}</td>
                                <td class="px-4 py-2">R$ {{ number_format($order->total_amount, 2, ',', '.') }}</td>
                                <td class="px-4 py-2">
                                    <span class="px-2 py-1 rounded text-sm 
                                        @if($order->status === 'pending') bg-yellow-100 text-yellow-800
                                        @elseif($order->status === 'paid') bg-green-100 text-green-800
                                        @elseif($order->status === 'shipped') bg-blue-100 text-blue-800
                                        @else bg-gray-100 text-gray-800
                                        @endif">
                                        {{ ucfirst($order->status) }}
                                    </span>
                                </td>
                                <td class="px-4 py-2">{{ $order->created_at->format('d/m/Y') }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @else
            <p class="text-gray-600">Nenhum pedido ainda.</p>
        @endif
    </div>
</div>
@endsection
