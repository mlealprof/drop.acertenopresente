@extends('layouts.app')

@section('title', 'Pagamento Pendente - Drop Acerte no Presente')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-lg shadow p-8 text-center">
        <div class="mb-8">
            <svg class="w-24 h-24 mx-auto text-yellow-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"></path>
            </svg>
        </div>

        <h1 class="text-4xl font-bold text-gray-900 mb-4">Pagamento Pendente</h1>
        <p class="text-xl text-gray-600 mb-8">Seu pagamento está sendo processado.</p>

        <div class="bg-yellow-50 border border-yellow-200 p-4 rounded-lg mb-8">
            <p class="text-gray-700">
                Aguarde alguns minutos enquanto confirmamos seu pagamento. Você receberá um email de confirmação em breve.
            </p>
        </div>

        <div class="space-y-4">
            <a href="{{ route('orders.index') }}" class="block w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 font-bold text-center">
                Ver Meus Pedidos
            </a>
            <a href="{{ route('dashboard') }}" class="block w-full bg-gray-600 text-white py-3 px-4 rounded-lg hover:bg-gray-700 font-bold text-center">
                Voltar ao Dashboard
            </a>
        </div>
    </div>
</div>
@endsection
