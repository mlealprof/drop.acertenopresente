@extends('layouts.app')

@section('title', 'Pagamento PIX - Drop Acerte no Presente')

@section('content')
<div class="max-w-2xl mx-auto">
    <h1 class="text-4xl font-bold text-gray-900 mb-8">Pagamento via PIX</h1>

    <div class="bg-white rounded-lg shadow p-8">
        <div class="mb-8">
            <h2 class="text-2xl font-bold text-gray-900 mb-4">Detalhes do Pedido</h2>
            <div class="bg-gray-50 p-4 rounded">
                <p class="text-gray-600"><strong>Número do Pedido:</strong> {{ $order->order_number }}</p>
                <p class="text-gray-600"><strong>Cliente:</strong> {{ $order->customer_name }}</p>
                <p class="text-gray-600"><strong>Produto:</strong> {{ $order->product_description }}</p>
                <p class="text-gray-600"><strong>Quantidade:</strong> {{ $order->quantity }}</p>
                <p class="text-2xl font-bold text-blue-600 mt-4">
                    Valor: R$ {{ number_format($order->total_amount, 2, ',', '.') }}
                </p>
            </div>
        </div>

        <div id="pix-container" class="mb-8">
            <button id="generate-pix-btn" class="w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 font-bold text-lg">
                Gerar QR Code PIX
            </button>
        </div>

        <div id="qr-code-container" class="hidden">
            <h3 class="text-xl font-bold text-gray-900 mb-4">Escaneie o QR Code com seu celular</h3>
            <div class="bg-white border-2 border-gray-300 p-8 rounded-lg text-center mb-6">
                <img id="qr-code-image" src="" alt="QR Code PIX" class="mx-auto" style="max-width: 300px;">
            </div>

            <div class="bg-yellow-50 border border-yellow-200 p-4 rounded-lg mb-6">
                <p class="text-sm text-gray-600 mb-2"><strong>Ou copie e cole o código:</strong></p>
                <div class="flex items-center gap-2">
                    <input type="text" id="copy-paste-code" readonly class="flex-1 p-2 border border-gray-300 rounded bg-white text-sm" />
                    <button id="copy-btn" class="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700">
                        Copiar
                    </button>
                </div>
            </div>

            <div class="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                <p class="text-sm text-gray-700">
                    <strong>Instruções:</strong> Abra seu app de banco ou Pix, selecione "Pagar com QR Code" ou "Copiar e Colar" e finalize a transação. O pagamento será processado automaticamente.
                </p>
            </div>

            <div class="mt-6">
                <p class="text-sm text-gray-600 text-center">
                    <strong>Status do Pagamento:</strong> <span id="payment-status" class="text-yellow-600">Aguardando...</span>
                </p>
            </div>
        </div>

        <div class="mt-8">
            <a href="{{ route('orders.index') }}" class="text-blue-600 hover:text-blue-800">
                ← Voltar para Pedidos
            </a>
        </div>
    </div>
</div>

<script>
document.getElementById('generate-pix-btn').addEventListener('click', async function() {
    this.disabled = true;
    this.textContent = 'Gerando QR Code...';

    try {
        const response = await fetch('{{ route("payment.generate-pix", $order->id) }}', {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': '{{ csrf_token() }}',
                'Content-Type': 'application/json'
            }
        });

        const data = await response.json();

        if (data.success) {
            // Exibir QR Code
            const qrCodeContainer = document.getElementById('qr-code-container');
            const qrImage = document.getElementById('qr-code-image');
            const copyPasteCode = document.getElementById('copy-paste-code');

            if (data.qr_code) {
                qrImage.src = 'data:image/png;base64,' + data.qr_code;
            }
            if (data.copy_paste) {
                copyPasteCode.value = data.copy_paste;
            }

            document.getElementById('pix-container').classList.add('hidden');
            qrCodeContainer.classList.remove('hidden');

            // Iniciar verificação de status
            checkPaymentStatus();
        } else {
            alert('Erro ao gerar QR Code: ' + data.error);
            this.disabled = false;
            this.textContent = 'Gerar QR Code PIX';
        }
    } catch (error) {
        console.error('Erro:', error);
        alert('Erro ao gerar QR Code');
        this.disabled = false;
        this.textContent = 'Gerar QR Code PIX';
    }
});

document.getElementById('copy-btn').addEventListener('click', function() {
    const copyPasteCode = document.getElementById('copy-paste-code');
    copyPasteCode.select();
    document.execCommand('copy');
    this.textContent = 'Copiado!';
    setTimeout(() => {
        this.textContent = 'Copiar';
    }, 2000);
});

function checkPaymentStatus() {
    const statusElement = document.getElementById('payment-status');
    
    const checkInterval = setInterval(async () => {
        try {
            const response = await fetch('{{ route("payment.check-status", $order->id) }}');
            const data = await response.json();

            if (data.status === 'completed') {
                statusElement.textContent = 'Pagamento Confirmado!';
                statusElement.className = 'text-green-600';
                clearInterval(checkInterval);
                
                setTimeout(() => {
                    window.location.href = '{{ route("payment.success") }}?preference_id=' + data.preference_id;
                }, 2000);
            } else if (data.status === 'failed') {
                statusElement.textContent = 'Pagamento Falhou';
                statusElement.className = 'text-red-600';
                clearInterval(checkInterval);
            }
        } catch (error) {
            console.error('Erro ao verificar status:', error);
        }
    }, 3000); // Verificar a cada 3 segundos

    // Parar de verificar após 24 horas
    setTimeout(() => {
        clearInterval(checkInterval);
    }, 24 * 60 * 60 * 1000);
}
</script>
@endsection
