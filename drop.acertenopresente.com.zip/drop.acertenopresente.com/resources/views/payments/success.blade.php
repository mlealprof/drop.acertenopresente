@extends('layouts.app')

@section('title', 'Pagamento Confirmado - Drop Acerte no Presente')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-lg shadow p-8 text-center">
        <div class="mb-8">
            <svg class="w-24 h-24 mx-auto text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7"></path>
            </svg>
        </div>

        <h1 class="text-4xl font-bold text-gray-900 mb-4">Pagamento Confirmado!</h1>
        <p class="text-xl text-gray-600 mb-8">Seu pedido foi pago com sucesso.</p>

        @if($payment)
            <div class="bg-gray-50 p-6 rounded-lg mb-8 text-left">
                <h2 class="text-lg font-bold text-gray-900 mb-4">Detalhes do Pagamento</h2>
                <p class="text-gray-600 mb-2"><strong>ID do Pagamento:</strong> {{ $payment->mercadopago_payment_id }}</p>
                <p class="text-gray-600 mb-2"><strong>Valor:</strong> R$ {{ number_format($payment->amount, 2, ',', '.') }}</p>
                <p class="text-gray-600 mb-2"><strong>Método:</strong> PIX</p>
                <p class="text-gray-600"><strong>Data:</strong> {{ $payment->payment_date->format('d/m/Y H:i') }}</p>
            </div>
        @endif

        <div class="bg-blue-50 border border-blue-200 p-4 rounded-lg mb-8">
            <p class="text-gray-700">
                Seu pedido está em processamento e será postado em breve. Você receberá um email com o rastreamento.
            </p>
        </div>

        <div class="space-y-4">
            <a href="{{ route('orders.paid') }}" class="block w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 font-bold text-center">
                Ver Pedidos Pagos
            </a>
            <a href="{{ route('dashboard') }}" class="block w-full bg-gray-600 text-white py-3 px-4 rounded-lg hover:bg-gray-700 font-bold text-center">
                Voltar ao Dashboard
            </a>
        </div>
    </div>
</div>
@endsection
