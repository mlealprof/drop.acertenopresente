@extends('layouts.app')

@section('title', 'Pagamento Falhou - Drop Acerte no Presente')

@section('content')
<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-lg shadow p-8 text-center">
        <div class="mb-8">
            <svg class="w-24 h-24 mx-auto text-red-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path>
            </svg>
        </div>

        <h1 class="text-4xl font-bold text-gray-900 mb-4">Pagamento Falhou</h1>
        <p class="text-xl text-gray-600 mb-8">Ocorreu um erro ao processar seu pagamento.</p>

        <div class="bg-red-50 border border-red-200 p-4 rounded-lg mb-8">
            <p class="text-gray-700">
                Por favor, tente novamente. Se o problema persistir, entre em contato com o suporte.
            </p>
        </div>

        <div class="space-y-4">
            <a href="{{ route('orders.index') }}" class="block w-full bg-blue-600 text-white py-3 px-4 rounded-lg hover:bg-blue-700 font-bold text-center">
                Tentar Novamente
            </a>
            <a href="{{ route('dashboard') }}" class="block w-full bg-gray-600 text-white py-3 px-4 rounded-lg hover:bg-gray-700 font-bold text-center">
                Voltar ao Dashboard
            </a>
        </div>
    </div>
</div>
@endsection
