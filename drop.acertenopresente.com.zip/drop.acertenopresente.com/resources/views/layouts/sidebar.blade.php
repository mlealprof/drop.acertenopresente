<aside class="w-64 bg-gray-800 text-white min-h-screen p-4">
    <ul class="space-y-2">
        @if(auth()->user()->isAffiliate())
            <li>
                <a href="{{ route('dashboard') }}" class="block p-2 rounded hover:bg-gray-700">
                    Dashboard
                </a>
            </li>
            <li>
                <a href="{{ route('products.index') }}" class="block p-2 rounded hover:bg-gray-700">
                    Catálogo de Produtos
                </a>
            </li>
            <li>
                <a href="{{ route('affiliate-products.index') }}" class="block p-2 rounded hover:bg-gray-700">
                    Meus Produtos
                </a>
            </li>
            <li>
                <a href="{{ route('orders.index') }}" class="block p-2 rounded hover:bg-gray-700">
                    Pedidos
                </a>
            </li>
            <li>
                <a href="{{ route('orders.paid') }}" class="block p-2 rounded hover:bg-gray-700">
                    Pedidos Pagos
                </a>
            </li>
        @elseif(auth()->user()->isAdmin())
            <li>
                <a href="{{ route('admin.dashboard') }}" class="block p-2 rounded hover:bg-gray-700">
                    Dashboard Admin
                </a>
            </li>
            <li>
                <a href="{{ route('admin.affiliates.index') }}" class="block p-2 rounded hover:bg-gray-700">
                    Afiliados
                </a>
            </li>
            <li>
                <a href="{{ route('admin.products.index') }}" class="block p-2 rounded hover:bg-gray-700">
                    Produtos
                </a>
            </li>
            <li>
                <a href="{{ route('admin.orders.index') }}" class="block p-2 rounded hover:bg-gray-700">
                    Pedidos
                </a>
            </li>
            <li>
                <a href="{{ route('admin.payments.index') }}" class="block p-2 rounded hover:bg-gray-700">
                    Pagamentos
                </a>
            </li>
        @endif
    </ul>
</aside>
