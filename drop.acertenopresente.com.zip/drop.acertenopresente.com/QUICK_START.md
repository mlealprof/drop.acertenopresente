# Guia Rápido de Início - Drop Acerte no Presente

## Instalação Rápida (5 minutos)

### 1. Clone o projeto
```bash
git clone https://seu-repositorio.git
cd drop.acertenopresente.com
```

### 2. Instale dependências
```bash
composer install
npm install
```

### 3. Configure o ambiente
```bash
cp .env.example .env
php artisan key:generate
```

### 4. Configure o banco de dados no `.env`
```
DB_DATABASE=seu_banco
DB_USERNAME=seu_usuario
DB_PASSWORD=sua_senha
```

### 5. Execute migrations
```bash
php artisan migrate
```

### 6. Inicie o servidor
```bash
php artisan serve
```

Acesse: `http://localhost:8000`

## Credenciais de Teste

### Admin
- Email: `admin@drop.acertenopresente.com`
- Senha: `admin123`

### Afiliado
- Email: `affiliate@drop.acertenopresente.com`
- Senha: `affiliate123`

## Estrutura de Pastas Importantes

| Pasta | Descrição |
|-------|-----------|
| `app/Models/` | Modelos Eloquent |
| `app/Http/Controllers/` | Controladores |
| `app/Http/Middleware/` | Middlewares |
| `routes/web.php` | Definição de rotas |
| `resources/views/` | Templates Blade |
| `database/migrations/` | Migrações do banco |

## Comandos Úteis

```bash
# Criar um novo modelo com migration
php artisan make:model NomeModelo -m

# Criar um novo controlador
php artisan make:controller NomeController

# Criar uma nova migration
php artisan make:migration create_table_name

# Executar migrations
php artisan migrate

# Desfazer última migration
php artisan migrate:rollback

# Resetar banco de dados
php artisan migrate:refresh

# Limpar cache
php artisan cache:clear

# Gerar cache otimizado
php artisan config:cache

# Acessar console interativo
php artisan tinker
```

## Fluxo de Desenvolvimento

### 1. Criar um novo recurso

```bash
# Criar modelo, migration e controlador
php artisan make:model Recurso -mcr
```

### 2. Definir rotas em `routes/web.php`

```php
Route::resource('recursos', RecursoController::class);
```

### 3. Implementar controlador

```php
public function index()
{
    $recursos = Recurso::all();
    return view('recursos.index', compact('recursos'));
}
```

### 4. Criar views em `resources/views/`

```blade
@extends('layouts.app')

@section('content')
    <!-- Seu conteúdo aqui -->
@endsection
```

## Autenticação

A autenticação é gerenciada pelo `AuthController`. Para proteger rotas:

```php
Route::middleware('auth')->group(function () {
    Route::get('/dashboard', [DashboardController::class, 'index']);
});
```

Para rotas administrativas:

```php
Route::middleware(['auth', 'admin'])->group(function () {
    Route::get('/admin/dashboard', [AdminController::class, 'dashboard']);
});
```

## Banco de Dados

### Tabelas Principais

- `users` - Usuários (afiliados e admins)
- `products` - Produtos disponíveis
- `affiliate_products` - Produtos selecionados por afiliados
- `orders` - Pedidos criados
- `payments` - Pagamentos
- `commission_history` - Histórico de comissões

### Relacionamentos

```
User hasMany Orders
User hasMany CommissionHistory
Product hasMany AffiliateProducts
AffiliateProduct belongsTo User, Product
Order belongsTo User
Order hasMany Payments
CommissionHistory belongsTo User, Order
```

## Validação

Use o `Validator` para validar dados:

```php
$validated = $request->validate([
    'name' => 'required|string|max:255',
    'email' => 'required|email|unique:users',
    'password' => 'required|min:8|confirmed',
]);
```

## Tratamento de Erros

Erros são automaticamente capturados e exibidos nas views. Use:

```blade
@if ($errors->any())
    @foreach ($errors->all() as $error)
        <p>{{ $error }}</p>
    @endforeach
@endif
```

## Mensagens Flash

```php
return redirect()->back()->with('success', 'Operação realizada com sucesso!');
return redirect()->back()->with('error', 'Erro ao processar a operação!');
```

## Upload de Arquivos

```php
if ($request->hasFile('file')) {
    $path = $request->file('file')->store('uploads', 'public');
}
```

## API JSON

Para retornar JSON:

```php
return response()->json([
    'status' => 'success',
    'data' => $data
]);
```

## Debugging

### Usar dd() para debug
```php
dd($variavel); // Exibe e para a execução
```

### Usar dump() para debug
```php
dump($variavel); // Exibe mas continua
```

### Verificar logs
```bash
tail -f storage/logs/laravel.log
```

## Performance

- Use eager loading: `User::with('orders')->get()`
- Implemente paginação: `$users->paginate(15)`
- Cache dados frequentes: `Cache::remember('key', 3600, fn() => ...)`

## Próximas Etapas

1. Customize as views conforme necessário
2. Adicione mais funcionalidades
3. Implemente testes automatizados
4. Configure CI/CD para deployment automático
5. Monitore performance e segurança

## Recursos Úteis

- [Documentação Laravel](https://laravel.com/docs)
- [Tailwind CSS](https://tailwindcss.com)
- [MySQL](https://dev.mysql.com/doc/)
- [Git](https://git-scm.com/doc)

