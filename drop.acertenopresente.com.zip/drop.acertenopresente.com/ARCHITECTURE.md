# Arquitetura da Plataforma de Dropshipping - Acerte no Presente

## 1. Visão Geral

A plataforma **drop.acertenopresente.com** é um sistema de gerenciamento de afiliados para dropshipping, desenvolvido em Laravel 11, que permite que afiliados gerenciem seus produtos, pedidos e comissões através de um dashboard intuitivo.

## 2. Estrutura do Banco de Dados

### 2.1 Tabelas Principais

#### **users**
- `id` (PK)
- `name` (string)
- `email` (string, unique)
- `password` (string)
- `user_type` (enum: 'affiliate', 'admin') - Define se é afiliado ou administrador
- `cpf` (string, unique) - Para afiliados
- `phone` (string)
- `status` (enum: 'active', 'inactive', 'suspended')
- `balance` (decimal) - Saldo do afiliado
- `commission_rate` (decimal) - Taxa de comissão do afiliado (padrão 10%)
- `created_at`, `updated_at`

#### **products**
- `id` (PK)
- `sku` (string, unique)
- `name` (string)
- `description` (text)
- `price` (decimal)
- `cost` (decimal) - Custo do produto
- `image_url` (string)
- `category` (string)
- `stock_quantity` (integer)
- `status` (enum: 'active', 'inactive')
- `created_at`, `updated_at`

#### **affiliate_products**
- `id` (PK)
- `affiliate_id` (FK → users)
- `product_id` (FK → products)
- `custom_price` (decimal, nullable) - Preço customizado pelo afiliado
- `commission_override` (decimal, nullable) - Comissão customizada
- `created_at`, `updated_at`

#### **orders**
- `id` (PK)
- `affiliate_id` (FK → users)
- `order_number` (string, unique)
- `status` (enum: 'pending', 'paid', 'in_production', 'shipped', 'delivered', 'cancelled')
- `total_amount` (decimal)
- `commission_amount` (decimal)
- `shipping_label_url` (string, nullable)
- `product_description` (text)
- `quantity` (integer)
- `sku` (string)
- `customer_name` (string)
- `customer_email` (string)
- `customer_phone` (string)
- `shipping_address` (text)
- `created_at`, `updated_at`

#### **payments**
- `id` (PK)
- `affiliate_id` (FK → users)
- `order_id` (FK → orders)
- `amount` (decimal)
- `payment_method` (string)
- `payment_date` (datetime)
- `status` (enum: 'pending', 'completed', 'failed')
- `transaction_id` (string, nullable)
- `created_at`, `updated_at`

#### **commission_history**
- `id` (PK)
- `affiliate_id` (FK → users)
- `order_id` (FK → orders)
- `commission_amount` (decimal)
- `commission_rate` (decimal)
- `status` (enum: 'pending', 'paid', 'cancelled')
- `paid_date` (datetime, nullable)
- `created_at`, `updated_at`

## 3. Modelos (Models)

### 3.1 User Model
- Relacionamentos: `hasMany('orders')`, `hasMany('commissions')`, `hasMany('affiliateProducts')`
- Scopes: `affiliates()`, `admins()`, `active()`
- Métodos: `getBalance()`, `updateBalance()`

### 3.2 Product Model
- Relacionamentos: `hasMany('affiliateProducts')`, `hasMany('orders')`
- Scopes: `active()`, `byCategory()`
- Métodos: `isAvailable()`, `getCommission()`

### 3.3 AffiliateProduct Model
- Relacionamentos: `belongsTo('user')`, `belongsTo('product')`
- Métodos: `getPrice()`, `getCommission()`

### 3.4 Order Model
- Relacionamentos: `belongsTo('user', 'affiliate_id')`, `hasMany('payments')`
- Scopes: `byAffiliate()`, `byStatus()`, `paid()`, `pending()`
- Métodos: `markAsPaid()`, `markAsShipped()`, `calculateCommission()`

### 3.5 Payment Model
- Relacionamentos: `belongsTo('user', 'affiliate_id')`, `belongsTo('order')`
- Métodos: `markAsCompleted()`, `markAsFailed()`

### 3.6 CommissionHistory Model
- Relacionamentos: `belongsTo('user', 'affiliate_id')`, `belongsTo('order')`
- Métodos: `markAsPaid()`, `calculateTotal()`

## 4. Controladores (Controllers)

### 4.1 AuthController
- `login()` - Exibe formulário de login
- `authenticate()` - Processa autenticação
- `logout()` - Realiza logout
- `register()` - Exibe formulário de registro (apenas para afiliados)
- `storeRegister()` - Armazena novo afiliado

### 4.2 DashboardController
- `index()` - Exibe dashboard do afiliado
- `getBalance()` - Retorna saldo atual
- `getPendingOrders()` - Retorna pedidos pendentes
- `getPaidOrders()` - Retorna pedidos pagos

### 4.3 ProductController
- `index()` - Lista todos os produtos disponíveis
- `show()` - Exibe detalhes do produto
- `search()` - Busca produtos por nome/SKU

### 4.4 AffiliateProductController
- `index()` - Lista produtos escolhidos pelo afiliado
- `add()` - Adiciona produto ao catálogo do afiliado
- `remove()` - Remove produto do catálogo
- `updatePrice()` - Atualiza preço customizado

### 4.5 OrderController
- `index()` - Lista pedidos do afiliado
- `create()` - Exibe formulário para criar pedido
- `store()` - Armazena novo pedido com upload de etiqueta
- `show()` - Exibe detalhes do pedido
- `updateStatus()` - Atualiza status do pedido

### 4.6 AdminController
- `dashboard()` - Dashboard administrativo
- `manageAffiliates()` - Gerencia afiliados
- `manageProducts()` - Gerencia produtos
- `manageOrders()` - Gerencia pedidos
- `managePayments()` - Gerencia pagamentos

## 5. Rotas (Routes)

### 5.1 Rotas Públicas
```
GET  /                          - Página inicial
GET  /login                     - Formulário de login
POST /login                     - Processa login
GET  /register                  - Formulário de registro
POST /register                  - Processa registro
POST /logout                    - Logout
```

### 5.2 Rotas Protegidas (Afiliados)
```
GET  /dashboard                 - Dashboard principal
GET  /dashboard/balance         - Saldo do afiliado
GET  /catalog                   - Catálogo de produtos
GET  /my-products               - Produtos escolhidos
GET  /orders                    - Pedidos
POST /orders                    - Criar novo pedido
GET  /orders/{id}               - Detalhes do pedido
PUT  /orders/{id}               - Atualizar pedido
GET  /paid-orders               - Pedidos pagos
```

### 5.3 Rotas Administrativas
```
GET  /admin/dashboard           - Dashboard admin
GET  /admin/affiliates          - Gerenciar afiliados
GET  /admin/products            - Gerenciar produtos
POST /admin/products            - Criar produto
PUT  /admin/products/{id}       - Atualizar produto
DELETE /admin/products/{id}     - Deletar produto
GET  /admin/orders              - Gerenciar pedidos
GET  /admin/payments            - Gerenciar pagamentos
```

## 6. Funcionalidades Principais

### 6.1 Autenticação
- Login com email e senha
- Registro de novos afiliados
- Recuperação de senha
- Diferenciação entre afiliados e administradores

### 6.2 Dashboard do Afiliado
- Exibição do saldo atual
- Histórico de comissões
- Estatísticas de vendas
- Gráficos de desempenho

### 6.3 Catálogo de Produtos
- Listagem de todos os produtos disponíveis
- Busca e filtro por categoria
- Detalhes do produto (preço, descrição, imagem)
- Possibilidade de adicionar produtos ao catálogo pessoal

### 6.4 Produtos Escolhidos
- Listagem de produtos selecionados pelo afiliado
- Possibilidade de customizar preço
- Remoção de produtos
- Visualização de comissão por produto

### 6.5 Gerenciamento de Pedidos
- Criação de novo pedido
- Upload de etiqueta de envio
- Inserção de descrição, quantidade e SKU
- Atualização de status do pedido
- Visualização de histórico de pedidos

### 6.6 Pedidos Pagos
- Listagem de pedidos com pagamento confirmado
- Status de produção/postagem
- Rastreamento de envio
- Confirmação de entrega

## 7. Segurança

- Autenticação via Laravel Breeze ou Fortify
- Autorização com Policies e Gates
- Validação de entrada em todos os formulários
- Proteção contra CSRF
- Hashing de senhas com bcrypt
- Rate limiting em endpoints críticos
- Sanitização de dados de entrada

## 8. Tecnologias Utilizadas

- **Backend**: Laravel 11
- **Frontend**: Blade Templates com Tailwind CSS
- **Banco de Dados**: MySQL 8.0+
- **Autenticação**: Laravel Breeze
- **Validação**: Laravel Validation
- **Upload de Arquivos**: Laravel Storage
- **Email**: Laravel Mail
- **Fila**: Laravel Queue (para processamento assíncrono)

## 9. Estrutura de Diretórios

```
drop.acertenopresente.com/
├── app/
│   ├── Models/
│   │   ├── User.php
│   │   ├── Product.php
│   │   ├── AffiliateProduct.php
│   │   ├── Order.php
│   │   ├── Payment.php
│   │   └── CommissionHistory.php
│   ├── Http/
│   │   ├── Controllers/
│   │   │   ├── AuthController.php
│   │   │   ├── DashboardController.php
│   │   │   ├── ProductController.php
│   │   │   ├── AffiliateProductController.php
│   │   │   ├── OrderController.php
│   │   │   └── AdminController.php
│   │   └── Requests/
│   ├── Policies/
│   └── Services/
├── database/
│   ├── migrations/
│   └── seeders/
├── resources/
│   ├── views/
│   │   ├── auth/
│   │   ├── dashboard/
│   │   ├── products/
│   │   ├── orders/
│   │   └── admin/
│   └── css/
├── routes/
│   ├── web.php
│   └── api.php
└── storage/
    └── app/
        └── uploads/
```

## 10. Fluxo de Negócio

1. **Registro de Afiliado**: Novo afiliado se registra na plataforma
2. **Seleção de Produtos**: Afiliado escolhe produtos do catálogo para vender
3. **Criação de Pedido**: Afiliado cria um novo pedido com detalhes do cliente
4. **Upload de Etiqueta**: Afiliado faz upload da etiqueta de envio
5. **Confirmação de Pagamento**: Admin confirma o pagamento do pedido
6. **Cálculo de Comissão**: Sistema calcula automaticamente a comissão
7. **Atualização de Status**: Pedido é marcado como em produção/postado
8. **Pagamento de Comissão**: Comissão é creditada no saldo do afiliado

## 11. Próximas Fases

- Integração com gateway de pagamento (Stripe, PayPal)
- Sistema de notificações por email
- API REST para integração com terceiros
- Aplicativo mobile
- Sistema de relatórios avançados
- Integração com transportadoras para rastreamento
